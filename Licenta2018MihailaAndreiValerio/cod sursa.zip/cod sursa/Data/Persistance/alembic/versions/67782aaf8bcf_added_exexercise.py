"""added exexercise

Revision ID: 67782aaf8bcf
Revises: c5aa0c52ab65
Create Date: 2018-05-16 22:36:06.068986

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '67782aaf8bcf'
down_revision = 'c5aa0c52ab65'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
