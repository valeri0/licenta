"""empty message

Revision ID: 2c76bce51992
Revises: 4a18edf22b41
Create Date: 2018-05-16 22:32:17.849024

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2c76bce51992'
down_revision = '4a18edf22b41'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
