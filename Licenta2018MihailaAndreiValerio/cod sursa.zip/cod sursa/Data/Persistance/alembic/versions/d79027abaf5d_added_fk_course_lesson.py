"""added fk course_lesson

Revision ID: d79027abaf5d
Revises: 6629488c7415
Create Date: 2018-05-17 02:02:59.961187

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd79027abaf5d'
down_revision = '6629488c7415'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
