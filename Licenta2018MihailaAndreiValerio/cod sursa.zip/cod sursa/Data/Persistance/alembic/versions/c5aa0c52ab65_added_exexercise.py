"""added exexercise

Revision ID: c5aa0c52ab65
Revises: 2c76bce51992
Create Date: 2018-05-16 22:33:34.278780

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c5aa0c52ab65'
down_revision = '2c76bce51992'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
